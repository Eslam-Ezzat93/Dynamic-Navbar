#Landing Page Project

## Overview
This project about building dynamic navbar and styling it using javascript only and styling it 

### Prequesties 
if you want to show code which i use you need to install text editor like visualStudio

#### built with 
we use basics of HTML, CSS and Javascript

##### Author
Eslam Ezzat


