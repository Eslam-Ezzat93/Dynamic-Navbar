/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
//structure
//logo
const navbar = document.querySelector(".navbar__menu");
const logo = "<h4>LANDING PAGE</h4>";
navbar.insertAdjacentHTML("afterbegin", logo);
//building list
const fragment = document.createDocumentFragment(); 
for (let i = 1; i <= 4; i++) {
    const listItem = document.createElement("li");
    const a = document.createElement("a");
    a.textContent = `Section ${i}` ;
    a.href = `#section${i}`;
    a.classList.add(`link${i}`);
    listItem.appendChild(a);
    fragment.appendChild(listItem);
}
document.getElementById("navbar__list").appendChild(fragment);
//style the nav
document.querySelector("header").style.cssText = " background: linear-gradient(45deg, rgba(136,203,171,1) 0%, rgba(0,13,60,1) 60%);";
navbar.style.cssText = " display: flex; justify-content: space-around;";
document.querySelector("ul").style.cssText = " margin-top: 20px; text-decoration: none; "


// Scroll to anchor ID using scrollTO event
document.addEventListener("click", function (e) {
    e.preventDefault();
    for(let i = 1; i <= 4; i++) { 
      const sec = document.querySelector(`#section${i}`);
      if(e.target && e.target.matches(`.link${i}`)) { 
                window.scrollTo({
         top: sec.offsetTop,
         behavior: 'smooth',
        });
      }
    }                  
});

// Add class 'active' to section when near top of viewport  .
document.addEventListener("scroll", function active() {
  for(let i = 1; i <= 4; i++) { 
    const sec = document.querySelector(`#section${i}`);
    const a = document.querySelector(`.link${i}`);
    if(sec.classList.contains("your-active-class") && a.classList.contains("active")){
              sec.classList.remove("your-active-class");
              a.classList.remove("active");
       }
  }
const links = document.querySelectorAll("a");
const secs = document.querySelectorAll("section");
const y = window.pageYOffset;

  for (let i = 0; i < 4; i++){ 
      if (y >= 200 && y < 900) {
        secs[0].classList.add("your-active-class");
        links[0].classList.add("active");
    }
    else if (y >= 950 && y <= 1600 ) {
      secs[1].classList.add("your-active-class");
      links[1].classList.add("active");
    }  
    else if (y >=1600 && y <= 2200) {
      secs[2].classList.add("your-active-class");
      links[2].classList.add("active"); 
    }     
    else if (y > 2200) {  
      secs[3].classList.add("your-active-class");
      links[3].classList.add("active");
    }      
  }    
});
